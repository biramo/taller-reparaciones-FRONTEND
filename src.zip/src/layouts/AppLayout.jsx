// layouts/AppLayout.jsx
import { Outlet } from "react-router-dom";
import Header from "../components/Header";
import Sidebar from "../components/Sidebar";
import Footer from "../components/Footer";

//Crea la plantilla de las paginas
//todas igual cambiando el main
export default function AppLayout() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <div className="flex flex-1">
        <Sidebar />

        <main className="grow p-4 bg-white">
          <Outlet />
        </main>
      </div>

      <Footer />
    </div>
  );
}