import { useState } from "react";
import { useNavigate } from "react-router-dom";
import {useAuth} from '../hooks/useAuth';



export default function Navbar() {
    const {logout}=useAuth();
    const navigate=useNavigate();
    const [activeDropDown, setActiveDropdown]=useState(false);


    const transitionBg="transition-colors duration-300 ease-in-out";
    const styles={
        navClass:"flex flex-wrap md:flex-nowrap justify-between gap-2 items-center py-4 px-4 border-b border-green-300 bg-emerald-950 text-emerald-50",
        
        elementNav:"bg-emerald-50 px-4 py-2 rounded text-emerald-900",

        elementNavInteractive:`hover:bg-emerald-200 hover:text-emerald-950 ${transitionBg}`,

        dropDownActive: "absolute right-0 top-16 bg-emerald-50 border-4 border-emerald-900 py-6 px-2 flex flex-col gap-3 font-bold items-center rounded",
        
        dropDown:"hidden",

        liElement: `rounded bg-white px-4 py-1.5 text-emerald-950 w-full text-center hover:bg-emerald-200 cursor-pointer ${transitionBg}`,

        logoutElement: `${transitionBg} bg-red-500 hover:bg-red-700 px-2 py-1.5 cursor-pointer rounded text-white`
    }
    
    return (
    <nav className={styles.navClass}>
      {/* LOGO / APP NAME */}
      <div className={`${styles.elementNav} ${styles.elementNavInteractive} cursor-pointer`}
        onClick={()=>navigate("/")}
      >
        <icon />
        <span >Gestión Taller</span>
      </div>

      {/* SEARCH GLOBAL */}
        <input
         className={`${styles.elementNav} w-full md:max-w-md`}
          type="text"
          placeholder="Buscar cliente, orden, pieza..."
        />

      {/* NOTIFICACIONES */}
      <div className={styles.elementNav}>
        <icon />
      </div>

      {/* USER MENU */}
      <div  className="relative">

        <button className={`${styles.elementNav} ${styles.elementNavInteractive} cursor-pointer`}
            onClick={()=>setActiveDropdown(!activeDropDown)}
        >
          <icon />
          <span>Usuario</span>
        </button>

        {/* DROPDOWN */}
        <ul className={activeDropDown?styles.dropDownActive:styles.dropDown}>
          <li className={styles.liElement}>Mi perfil</li>
          <li className={styles.liElement}>Configuración</li>
          <li className="text-emerald-950">──────────</li>
          <li
            className={styles.logoutElement}
            onClick={()=>logout()}
          >Cerrar sesión</li>
        </ul>

      </div>

    </nav>
  );
}