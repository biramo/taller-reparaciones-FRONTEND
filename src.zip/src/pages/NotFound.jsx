export default function NotFound(){
    return (

        <main>Pagina no encontrada</main>
    )
}