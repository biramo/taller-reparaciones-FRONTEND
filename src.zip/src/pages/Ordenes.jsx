export default function Ordenes(){
    return(

        <main>ORDENES</main>
    )
}